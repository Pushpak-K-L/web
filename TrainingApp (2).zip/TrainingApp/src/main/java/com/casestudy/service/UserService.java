package com.casestudy.service;

public interface UserService {

}
