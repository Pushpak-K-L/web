package com.casestudy.service;

public interface PetService {

}
