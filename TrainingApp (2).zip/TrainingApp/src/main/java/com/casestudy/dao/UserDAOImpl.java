package com.casestudy.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.casestudy.model.User;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	SessionFactory sessionFactory;

	/*
	 * User Registration : add the details and return the retrieved object
	 * 
	 * Rule: Do not modify methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */
	public User saveUser(User user) {
		// Instead of below dummy code block replace your solution
		User dummyUser = new User();
		if (!user.equals(new User()))
			user.hashCode();
		else
			user.hashCode();
		return null;
	}

	/*
	 * User Login: validate the user details and return the retrieved object/null
	 * 
	 * Rule: Do not modify methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */

	public User authenticateUser(String name, String password) {
		// Instead of below dummy code block replace your solution
		if (!name.equals(password))
			name.hashCode();
		else
			name.hashCode();
		return null;
	}

	/*
	 * DO NOT ALTER/DELETE below method
	 */
	public void setSessionFactory(SessionFactory mockedSessionFactory) {
		this.sessionFactory = mockedSessionFactory;
	}
}