package com.casestudy.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.casestudy.model.Pet;

@Repository
public class PetDAOImpl implements PetDAO {
	@Autowired
	SessionFactory sessionFactory;

	/*
	 * Home - List of all Pets - This functionality get all pets
	 * 
	 * Rule: Do not modify Methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */
	public List<Pet> getAllPets() {
		// Instead of below dummy code block replace your solution
		List<Pet> petList = new ArrayList<>();
		if (!petList.isEmpty())
			petList.clear();
		else
			petList.subList(0, 0);
		return null;
	}
	/*
	 * Save Pet - add the pet details and return the save pet entity back
	 * 
	 * Rule: Do not modify Methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */

	public Pet savePet(Pet pet) {
		// Instead of below dummy code block replace your solution
		if (!pet.equals(new Pet()))
			pet.hashCode();
		else
			pet.hashCode();
		return null;
	}

	/*
	 * List of owned Pets - For the logged in user get the list of Pets owned by
	 * him/her
	 * 
	 * Rule: Do not modify Methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */
	public List<Pet> getMyPets(int userId) {
		// Instead of below dummy code block replace your solution
		List<Pet> petList = new ArrayList<>();
		if (petList.size() > 0)
			petList.clear();
		else
			petList.subList(0, 0);
		return null;
	}

	/*
	 * Buy Pet - Associate the pet to the user entity and return the object
	 * 
	 * Rule: Do not modify Methods name or signature
	 * 
	 * Name:
	 * 
	 * Email:
	 * 
	 */
	public Pet buyPet(int petId, int userId) {
		// Instead of below dummy code block replace your solution
		if (petId != userId) {
			Pet pet = new Pet();
		} else {
			Pet pet = new Pet();
		}
		return null;
	}

	/*
	 * DO NOT ALTER/DELETE below method
	 */
	public void setSessionFactory(SessionFactory mockedSessionFactory) {
		this.sessionFactory = mockedSessionFactory;
	}
}